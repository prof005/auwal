import React, { useState, useEffect } from 'react';
import { Birthday } from './types/birthday';
import { saveBirthdays, loadBirthdays } from './utils/storage';
import Header from './components/Header';
import BirthdayForm from './components/BirthdayForm';
import BirthdayList from './components/BirthdayList';

function App() {
  const [birthdays, setBirthdays] = useState<Birthday[]>([]);

  useEffect(() => {
    const savedBirthdays = loadBirthdays();
    setBirthdays(savedBirthdays);
  }, []);

  useEffect(() => {
    saveBirthdays(birthdays);
  }, [birthdays]);

  const handleAddBirthday = (birthdayData: Omit<Birthday, 'id' | 'createdAt'>) => {
    const newBirthday: Birthday = {
      ...birthdayData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    
    setBirthdays(prev => [...prev, newBirthday]);
  };

  const handleUpdateBirthday = (id: string, updates: Partial<Birthday>) => {
    setBirthdays(prev =>
      prev.map(birthday =>
        birthday.id === id ? { ...birthday, ...updates } : birthday
      )
    );
  };

  const handleDeleteBirthday = (id: string) => {
    setBirthdays(prev => prev.filter(birthday => birthday.id !== id));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Header />
      
      <main className="py-8 px-4">
        <BirthdayForm onAdd={handleAddBirthday} />
        <BirthdayList
          birthdays={birthdays}
          onUpdate={handleUpdateBirthday}
          onDelete={handleDeleteBirthday}
        />
      </main>
      
      <footer className="text-center py-8 text-gray-500">
        <p>Made with ❤️ to help you remember special moments</p>
      </footer>
    </div>
  );
}

export default App;