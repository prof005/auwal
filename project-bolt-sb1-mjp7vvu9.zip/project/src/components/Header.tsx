import React from 'react';
import { Gift, Cake } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 text-white py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="flex items-center justify-center gap-3 mb-2">
          <div className="relative">
            <Gift className="w-8 h-8" />
            <Cake className="w-4 h-4 absolute -top-1 -right-1 text-yellow-300" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold">Birthday Reminders</h1>
        </div>
        <p className="text-center text-purple-100 text-lg">
          Never forget a special day again
        </p>
      </div>
    </header>
  );
};

export default Header;