import React, { useState } from 'react';
import { Search, CalendarDays, Users } from 'lucide-react';
import { Birthday } from '../types/birthday';
import { sortBirthdaysByDate } from '../utils/dateUtils';
import BirthdayItem from './BirthdayItem';

interface BirthdayListProps {
  birthdays: Birthday[];
  onUpdate: (id: string, updates: Partial<Birthday>) => void;
  onDelete: (id: string) => void;
}

const BirthdayList: React.FC<BirthdayListProps> = ({ birthdays, onUpdate, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredBirthdays = birthdays.filter(birthday =>
    birthday.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const sortedBirthdays = sortBirthdaysByDate(filteredBirthdays);

  if (birthdays.length === 0) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
          <CalendarDays className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">No birthdays yet</h3>
          <p className="text-gray-500">Add your first birthday reminder to get started!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search birthdays..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-4">
        <Users className="w-5 h-5 text-purple-600" />
        <h2 className="text-xl font-semibold text-gray-800">
          Upcoming Birthdays ({sortedBirthdays.length})
        </h2>
      </div>

      <div className="space-y-4">
        {sortedBirthdays.map((birthday) => (
          <BirthdayItem
            key={birthday.id}
            birthday={birthday}
            onUpdate={onUpdate}
            onDelete={onDelete}
          />
        ))}
      </div>

      {filteredBirthdays.length === 0 && searchTerm && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center">
          <Search className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No birthdays found matching "{searchTerm}"</p>
        </div>
      )}
    </div>
  );
};

export default BirthdayList;