import React, { useState } from 'react';
import { Edit2, Trash2, Calendar, Gift, Save, X } from 'lucide-react';
import { Birthday } from '../types/birthday';
import { formatDate, getDaysUntilBirthday, getAge } from '../utils/dateUtils';

interface BirthdayItemProps {
  birthday: Birthday;
  onUpdate: (id: string, updates: Partial<Birthday>) => void;
  onDelete: (id: string) => void;
}

const BirthdayItem: React.FC<BirthdayItemProps> = ({ birthday, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(birthday.name);
  const [editDate, setEditDate] = useState(birthday.date);

  const daysUntil = getDaysUntilBirthday(birthday.date);
  const age = getAge(birthday.date);
  const isToday = daysUntil === 0;
  const isUpcoming = daysUntil <= 7 && daysUntil > 0;

  const handleSave = () => {
    if (!editName.trim() || !editDate) return;
    
    onUpdate(birthday.id, {
      name: editName.trim(),
      date: editDate,
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditName(birthday.name);
    setEditDate(birthday.date);
    setIsEditing(false);
  };

  const getBirthdayMessage = () => {
    if (isToday) return "🎉 Today!";
    if (daysUntil === 1) return "🎂 Tomorrow";
    if (isUpcoming) return `🎈 In ${daysUntil} days`;
    return `In ${daysUntil} days`;
  };

  const getCardStyle = () => {
    if (isToday) return "bg-gradient-to-r from-yellow-400 to-orange-500 text-white shadow-xl transform scale-105";
    if (isUpcoming) return "bg-gradient-to-r from-pink-50 to-purple-50 border-pink-200 shadow-md";
    return "bg-white border-gray-200 hover:shadow-md";
  };

  if (isEditing) {
    return (
      <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
        <div className="space-y-3">
          <input
            type="text"
            value={editName}
            onChange={(e) => setEditName(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            placeholder="Name"
          />
          <input
            type="date"
            value={editDate}
            onChange={(e) => setEditDate(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          />
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded-lg font-medium transition-colors duration-200 flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save
            </button>
            <button
              onClick={handleCancel}
              className="px-3 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`border rounded-xl p-4 transition-all duration-300 ${getCardStyle()}`}>
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <Gift className={`w-5 h-5 ${isToday || isUpcoming ? 'text-pink-600' : 'text-purple-600'}`} />
            <h3 className={`font-semibold text-lg ${isToday ? 'text-white' : 'text-gray-800'}`}>
              {birthday.name}
            </h3>
          </div>
          
          <div className="space-y-1">
            <div className={`flex items-center gap-2 text-sm ${isToday ? 'text-yellow-100' : 'text-gray-600'}`}>
              <Calendar className="w-4 h-4" />
              <span>{formatDate(birthday.date)} • Turning {age + 1}</span>
            </div>
            
            <div className={`font-medium ${isToday ? 'text-white text-lg' : isUpcoming ? 'text-pink-600' : 'text-gray-700'}`}>
              {getBirthdayMessage()}
            </div>
          </div>
        </div>
        
        <div className="flex gap-2 ml-4">
          <button
            onClick={() => setIsEditing(true)}
            className={`p-2 rounded-lg transition-colors duration-200 ${
              isToday 
                ? 'bg-white/20 hover:bg-white/30 text-white' 
                : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
            }`}
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(birthday.id)}
            className={`p-2 rounded-lg transition-colors duration-200 ${
              isToday 
                ? 'bg-white/20 hover:bg-red-500 text-white' 
                : 'bg-gray-100 hover:bg-red-500 hover:text-white text-gray-600'
            }`}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default BirthdayItem;