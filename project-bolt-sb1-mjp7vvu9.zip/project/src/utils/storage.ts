import { Birthday } from '../types/birthday';

const STORAGE_KEY = 'birthday-reminders';

export const saveBirthdays = (birthdays: Birthday[]): void => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(birthdays));
};

export const loadBirthdays = (): Birthday[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  
  try {
    return JSON.parse(stored);
  } catch {
    return [];
  }
};