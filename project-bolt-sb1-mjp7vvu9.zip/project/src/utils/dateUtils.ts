export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    month: 'long', 
    day: 'numeric' 
  });
};

export const getDaysUntilBirthday = (dateString: string): number => {
  const today = new Date();
  const birthday = new Date(dateString);
  
  // Set birthday to current year
  birthday.setFullYear(today.getFullYear());
  
  // If birthday has passed this year, set to next year
  if (birthday < today) {
    birthday.setFullYear(today.getFullYear() + 1);
  }
  
  const diffTime = birthday.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  return diffDays;
};

export const getAge = (dateString: string): number => {
  const today = new Date();
  const birthDate = new Date(dateString);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
};

export const sortBirthdaysByDate = (birthdays: Birthday[]): Birthday[] => {
  return birthdays.sort((a, b) => {
    const daysA = getDaysUntilBirthday(a.date);
    const daysB = getDaysUntilBirthday(b.date);
    return daysA - daysB;
  });
};